import React, { Component } from "react";
import "../../../../../assets/css/work.less"




class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
            
        };
    }
    render() {

        return (
            <>
                <div className="container">
                    <h1>MY Courses</h1>
                </div>
            </>
        );
    }
}

export default Index;