import React, { Component } from "react";
import { Link } from "react-router-dom";
import "../../../../assets/css/feedback.less"

class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {

        return (
            <>
                <div classNameName="login vertical-center">
                    <div>
                        
                    </div>
                </div>
            </>
        );
    }
}

export default Index;